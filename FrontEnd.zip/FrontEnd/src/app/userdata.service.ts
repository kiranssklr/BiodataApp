import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class UserdataService {

  constructor(private http : HttpClient, private auth : AuthService) { }

  addUser(user){
    return this.http.post('http://localhost:5000/addUser',{'newUser' : user})
    .subscribe(data => {console.log(data)});
  }
}
