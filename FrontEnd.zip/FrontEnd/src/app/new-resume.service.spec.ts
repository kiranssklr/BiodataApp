import { TestBed } from '@angular/core/testing';

import { NewResumeService } from './new-resume.service';

describe('NewResumeService', () => {
  let service: NewResumeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NewResumeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
