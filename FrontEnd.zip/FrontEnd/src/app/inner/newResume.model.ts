export class newResumeModel {
    constructor(
        public userid : string,
        public name : string,
        public f_name : string,
        public m_name : string,
        public phone : number,
        public email : string,
        public age : number,
        public dob : Date,
        public gender : string,
        public address : string,
        public pin : number,
        public qualification : string,
        public objective : string
    ){}
}