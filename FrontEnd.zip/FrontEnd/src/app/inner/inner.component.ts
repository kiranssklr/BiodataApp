import { Component, OnInit } from '@angular/core';
import { NewResumeService } from '../new-resume.service';
import { Router } from '@angular/router';
import { newResumeModel } from './newResume.model';
import { AuthService } from '../auth.service';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-inner',
  templateUrl: './inner.component.html',
  styleUrls: ['./inner.component.css']
})
export class InnerComponent implements OnInit {
  
  
  newResumeItem = new newResumeModel('fddf',null,null,null,null,null,null,null,null,null,null,null,null);

  constructor(private newResume : NewResumeService, private router : Router, private auth : AuthService, private login : LoginComponent) {
    console.log('df');
  }
  
  ngOnInit(): void {
  }

  addResume(){
    this.newResume.addNewResume(this.newResumeItem);
    alert('Your resume added successfully');
    console.log(this.newResumeItem);
  }

}
