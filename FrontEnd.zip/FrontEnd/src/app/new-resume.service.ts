import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NewResumeService {

  constructor(private http : HttpClient) { }

  addNewResume(details){
    return this.http.post('http://localhost:5000/addResume',{'resume' : details})
    .subscribe();    
  }
}

