import { Component, OnInit } from '@angular/core';
import { UserdataService } from '../userdata.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private userData : UserdataService, private router : Router) { }

  newUser = {
    email : '',
    password : ''
  }

  ngOnInit(): void {
  }
  signupUser(){
    this.userData.addUser(this.newUser);
    this.router.navigate(['/']);

  }

}
